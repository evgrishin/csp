<?php
class msOrderLog extends xPDOSimpleObject {}